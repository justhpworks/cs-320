package apptmilestone;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
	private Map<String, Appointment> appointments = new HashMap<>(); // Map to store appointments with IDs = Key //
	
	// Method for adding an appointment //
	
	public void addAppointment(Appointment appointment) {
		if (appointments.containsKey(appointment.getAppointmentID())) {
			throw new IllegalArgumentException("Appointment with this ID already exists.");
		}
		appointments.put(appointment.getAppointmentID(), appointment); 
	}

	// Method for deleting an appointment //
		
	public void deleteAppointment(String appointmentID) {
		if (!appointments.containsKey(appointmentID)) {
			throw new IllegalArgumentException("Appointment with this ID does not exist.");
		}
		appointments.remove(appointmentID);
	}
}
