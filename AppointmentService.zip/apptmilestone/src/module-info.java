/**
 * 
 */
/**
 * 
 */
module apptmilestone {
	requires org.junit.jupiter.api;
}