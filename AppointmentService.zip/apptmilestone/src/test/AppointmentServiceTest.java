package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import apptmilestone.Appointment;
import apptmilestone.AppointmentService;

import java.util.Date;

public class AppointmentServiceTest {

    private AppointmentService appointmentService;

    // Initializes appointmentService object before each test run //
    
    public void setUp() {
        appointmentService = new AppointmentService();
    }

    // Method for creating future date for appointment testing //
    private Date getFutureDate() {
        return new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // Checks for one day (+24hrs) in the future //
    }

    // Test case for adding a valid appointment //
    @Test
    public void testAddAppointment() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Valid test description.");
        appointmentService.addAppointment(appointment);
        
        Assertions.assertEquals("12345", appointment.getAppointmentID());
        Assertions.assertEquals("Test Description", appointment.getDescription());
    }

    // Test case for adding an appointment with a duplicate appointmentID //

    public void testAddDuplicateAppointment() {
        Appointment appointment1 = new Appointment("12345", getFutureDate(), "First appointment");
        Appointment appointment2 = new Appointment("12345", getFutureDate(), "Duplicate test appointment"); // <-- duplicate appointmentID check //

        appointmentService.addAppointment(appointment1);

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(appointment2);
        });
    }

    // Test case for deleting an existing appointment //
    @Test
    public void testDeleteAppointment() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Valid test description.");
        appointmentService.addAppointment(appointment);
        
        appointmentService.deleteAppointment("12345");

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.deleteAppointment("12345");
        });
    }

    // Test case for deleting an appointment with an appointmentID that does not exist //
    @Test
    public void testDeleteNonExistentAppointment() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.deleteAppointment("54321"); // <--- invalid appointmentID //
        });
    }
}
