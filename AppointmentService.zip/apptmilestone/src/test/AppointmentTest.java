package test;

import java.util.Date; // used for appointmentDate //

import org.junit.jupiter.api.Assertions;
import apptmilestone.Appointment;

public class AppointmentTest {

    // Method to create time/clock for calculation //
    private Date getDateOffset(long offsetInMillis) {
        return new Date(System.currentTimeMillis() + offsetInMillis);
    }

    // Test case for valid appointment creation //
    
    public void testValidAppointmentCreation() {
        Date futureDate = getDateOffset(24 * 60 * 60 * 1000); // Checks for one day (+24hrs) in the future //

        Appointment appointment = new Appointment("12345", futureDate, "Valid test description.");
        
        Assertions.assertEquals("12345", appointment.getAppointmentID()); // Checks for valid appointmentID //
        Assertions.assertEquals(futureDate, appointment.getAppointmentDate()); // Checks for valid appointmentDate //
        Assertions.assertEquals("Valid test description.", appointment.getDescription()); // Checks for valid description //
    }
    
    // Test case for null appointmentID //
    
    public void testNullAppointmentID() {
        Date futureDate = getDateOffset(24 * 60 * 60 * 1000);

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Valid test description.");
        });
    }

    // Test case for appointmentID being too long //
    
    public void testAppointmentIDExceedsMaxLength() {
        Date futureDate = getDateOffset(24 * 60 * 60 * 1000); // Checks for one day (+24hrs) in the future //

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Valid test description.");
        });
    }

    // Test case for null appointmentDate //
    
    public void testNullAppointmentDate() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Valid test description.");
        });
    }

    // Test case for appointmentDate set in the past //
    
    public void testAppointmentDateInThePast() {
        Date pastDate = getDateOffset(-24 * 60 * 60 * 1000); // Checks for one day (-24hrs) in the past //

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", pastDate, "Valid description");
        });
    }

    // Test case for null description //

    public void testNullDescription() {
        Date futureDate = getDateOffset(24 * 60 * 60 * 1000);

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, null);
        });
    }

    // Test case for description being too long //
    
    public void testDescriptionExceedsMaxLength() {
        Date futureDate = getDateOffset(24 * 60 * 60 * 1000);
        String longDescription = "This description is far too long to be valid. It exceeds fifty characters.";

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, longDescription);
        });
    }
}