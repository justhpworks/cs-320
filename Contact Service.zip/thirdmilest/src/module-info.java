/**
 * 
 */
/**
 * 
 */
module thirdmilest {
	requires org.junit.jupiter.api;
}