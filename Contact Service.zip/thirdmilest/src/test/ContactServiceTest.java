	package test;

	import static org.junit.jupiter.api.Assertions.*;
	import org.junit.jupiter.api.BeforeEach;
	import org.junit.jupiter.api.Test;
	
	import thirdmilest.Contact;
	import thirdmilest.ContactService;

	class ContactServiceTest {
		
		private ContactService contactService;
	    private Contact contact;
	    
	    // Configures before each test //
	    
	    @BeforeEach
	    public void setUp() {
	        contactService = new ContactService();
	        contact = new Contact("12345", "Jane", "Doe", "1234567890", "73 Easy Street");
	    }
	    
	    // Test case for adding a new contact //
	    
	    @Test
	    public void testAddContact() {
	        contactService.addContact(contact);
	        assertEquals(contact, contactService.getContactByID("12345"));
	    }
	    
	    // Test case for adding a contact with an existing contactID //
	    
	    @Test
	    public void testAddContactWithExistingID() {
	        contactService.addContact(contact);
	        assertThrows(IllegalArgumentException.class, () -> {
	            contactService.addContact(contact); // adding the same Contact w/ existing contactID should throw an exception //
	        });
	    }
	    
	    // Test case for deleting a Contact //
	    @Test
	    public void testDeleteContact() {
	        contactService.addContact(contact);
	        contactService.deleteContact("12345");
	        assertThrows(IllegalArgumentException.class, () -> {
	            contactService.getContactByID("12345"); // After deletion, trying to get the contact should throw an exception //
	        });
	    }
	    
	    // Test case for deleting a contact that doesn't exist //
	    
	    @Test
	    public void testDeleteNonExistentContact() {
	        assertThrows(IllegalArgumentException.class, () -> {
	            contactService.deleteContact("12345"); // if the contactID does not exist, it should throw an exception //
	        });
	    }
	    
	    // Test case for updating a contact that does not exist //
	    @Test
	    public void testUpdateNonExistentContact() {
	        assertThrows(IllegalArgumentException.class, () -> {
	            contactService.updateFirstName("12345", "Michael"); // if contactID is not found, an exception will be thrown //
	        });
	        
	    }

	    // Test for updating firstName //
	    
	    @Test
	    public void testUpdateFirstName() {
	        contactService.addContact(contact);
	        contactService.updateFirstName("12345", "John");
	        assertEquals("John", contact.getFirstName());
	    }

	    // Test case for updating lastName //
	    
	    @Test
	    public void testUpdateLastName() {
	        contactService.addContact(contact);
	        contactService.updateLastName("12345", "Smith");
	        assertEquals("Smith", contact.getLastName());
	    }

	    // Test case for updating phone field //
	    
	    @Test
	    public void testUpdatePhone() {
	        contactService.addContact(contact);
	        contactService.updatePhone("12345", "0987654321");
	        assertEquals("0987654321", contact.getPhone());
	    }

	    // Test case for updating address field //
	    
	    @Test
	    public void testUpdateAddress() {
	        contactService.addContact(contact);
	        contactService.updateAddress("12345", "456 Elm St");
	        assertEquals("456 Elm St", contact.getAddress());
	    }
	}

