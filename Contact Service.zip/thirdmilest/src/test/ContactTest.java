package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import thirdmilest.Contact;

class ContactTest {
	    // Tests to see if Constructor has valid Inputs //
	    @Test
	    public void testConstructorValidInputs() {
	        Contact contact = new Contact("12345", "Jane", "Doe", "1234567890", "73 Easy Street");
	        assertEquals("12345", contact.getContactID());
	        assertEquals("Jane", contact.getFirstName());
	        assertEquals("Doe", contact.getLastName());
	        assertEquals("1234567890", contact.getPhone());
	        assertEquals("73 Easy Street", contact.getAddress());
	    }

	    // Tests to see the condition of an invalid contactID in Constructor //
	    
	    @Test
	    public void testConstructorInvalidContactID() {
	        assertThrows(IllegalArgumentException.class, () -> {
	            new Contact(null, "Jane", "Doe", "1234567890", "73 Easy Street");
	        });
	        assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("12345678901", "Jane", "Doe", "1234567890", "73 Easy Street");
	        });
	    }

	    // Testing Constructor with an invalid firstName field //
	    @Test
	    public void testConstructorInvalidFirstName() {
	        assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("12345", null, "Doe", "1234567890", "73 Easy Street");
	        });
	        assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("12345", "TooLongNameTesting", "Doe", "1234567890", "73 Easy Street");
	        });
	    }

	    // Testing Constructor with an invalid lastName field //
	    
	    @Test
	    public void testConstructorInvalidLastName() {
	        assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("12345", "Jane", null, "1234567890", "73 Easy Street");
	        });
	        assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("12345", "Jane", "TooLongNameTesting", "1234567890", "73 Easy Street");
	        });
	    }

	    // Testing Constructor with an invalid phone field //
	    
	    @Test
	    public void testConstructorInvalidPhone() {
	        assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("12345", "Jane", "Doe", null, "73 Easy Street");
	        });
	        assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("12345", "Jane", "Doe", "12345", "73 Easy Street");
	        });
	        assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("12345", "Jane", "Doe", "jihgfedcba", "73 Easy Street");
	        });
	    }

	    // Testing Constructor with an invalid address field //
	    
	    @Test
	    public void testConstructorInvalidAddress() {
	        assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("12345", "Jane", "Doe", "1234567890", null);
	        });
	        assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("12345", "Jane", "Doe", "1234567890", "This address exceeds system character length requirements.");
	        });
	    }

	    // Testing Setters with valid input data (updating information) //
	    
	    @Test
	    public void testSettersValidData() {
	        Contact contact = new Contact("12345", "Jane", "Doe", "1234567890", "73 Easy Street");

	        contact.setFirstName("John");
	        assertEquals("John", contact.getFirstName());

	        contact.setLastName("Walsh");
	        assertEquals("Walsh", contact.getLastName());

	        contact.setPhone("0987654321");
	        assertEquals("0987654321", contact.getPhone());

	        contact.setAddress("13 Woodbury Ln");
	        assertEquals("13 Woodbury Ln", contact.getAddress());
	    }

	    // Testing Setters with invalid input data //
	    
	    @Test
	    public void testSettersInvalidData() {
	        Contact contact = new Contact("12345", "Jane", "Doe", "1234567890", "73 Easy Street");

	        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null)); // no firstName entered //
	        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("TooLongNameTesting")); // firstName is too long //

	        assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null)); // no lastName entered //
	        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("TooLongNameTesting")); // lastName is too long //

	        assertThrows(IllegalArgumentException.class, () -> contact.setPhone(null)); // null phone field //
	        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("12345")); // field is too short //
	        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("jihgfedcba")); // not supposed to use alphabetical characters //

	        assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null)); // null address //
	        assertThrows(IllegalArgumentException.class, () -> contact.setAddress("This address exceeds system character length requirements.")); // address length is too long //
	    }
	}

