package thirdmilest;

	import java.util.HashMap;
	import java.util.Map;

	public class ContactService {
		// Map to store appointments with Contacts //
		
	    private final Map<String, Contact> contacts = new HashMap<>();

	    // Adds a new Contact with a new ContactID //
	    
	    public void addContact(Contact contact) {
	        if (contacts.containsKey(contact.getContactID())) {
	            throw new IllegalArgumentException("ContactID already exists.");
	        }
	        contacts.put(contact.getContactID(), contact);
	    }

	    // Deletes a Contact via ContactID //
	    
	    public void deleteContact(String contactID) {
	        if (!contacts.containsKey(contactID)) {
	            throw new IllegalArgumentException("ContactID not found.");
	        }
	        contacts.remove(contactID);
	    }

	    // Update firstName by contactID //
	    
	    public void updateFirstName(String contactID, String firstName) {
	        Contact contact = getContactByID(contactID);
	        contact.setFirstName(firstName);
	    }

	    // Update lastName by contactID //
	    
	    public void updateLastName(String contactID, String lastName) {
	        Contact contact = getContactByID(contactID);
	        contact.setLastName(lastName);
	    }

	    // Update phone by contactID //
	    
	    public void updatePhone(String contactID, String phone) {
	        Contact contact = getContactByID(contactID);
	        contact.setPhone(phone);
	    }

	    // Update address by contactID //
	    
	    public void updateAddress(String contactID, String address) {
	        Contact contact = getContactByID(contactID);
	        contact.setAddress(address);
	    }

	    // Gets a contact by contactID //
	    
	    public Contact getContactByID(String contactID) {
	        if (!contacts.containsKey(contactID)) {
	            throw new IllegalArgumentException("ContactID not found.");
	        }
	        return contacts.get(contactID);
	    }
	}

