package modulefourtask;

public class Task {
	private String taskID;
	private String name;
	private String description;
	
	// Constructor //
	
	public Task(String taskID, String name, String description) {
		if (taskID == null || taskID.length() > 10) {
			throw new IllegalArgumentException("The task ID shall not be null AND shall not be updatable.");
		}
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("The name field shall not be null OR over 20 characters in length.");
		}
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("The description field shall not be null OR over 50 characters in length.");
		}
}
// Method for retrieving variables (Getters) //
	public String getTaskID() {
		return taskID;
}

	public String getName() {
		return name;
}
	
	public String getDescription() {
		return description;
	}
// Method for setting variables (Setters)
	
	public void setName(String name) {
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("The name field shall not be null OR over 20 characters in length.");
		}
		this.name = name;
		}
	
	public void setDescription(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("The description field shall not be null OR over 50 characters in length.");
		}
		this.description = description;
	}
	
}