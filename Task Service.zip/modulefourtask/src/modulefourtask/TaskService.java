package modulefourtask;

import java.util.HashMap;
import java.util.Map;

public class TaskService { // The task service uses in-memory data structures to support storing tasks  (HashMap below) //
    private Map<String, Task> taskMap = new HashMap<>();

// Adds a task with a unique ID "The task service shall be able to add tasks with a unique ID." //
    public void addTask(Task task) {
        if (taskMap.containsKey(task.getTaskID())) {
            throw new IllegalArgumentException("Task ID must be unique.");
        }
        taskMap.put(task.getTaskID(), task);
    }

// Deletes a task by taskID "The task service shall be able to delete tasks per task ID." //
    public void deleteTask(String taskID) {
        if (!taskMap.containsKey(taskID)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        taskMap.remove(taskID);
    }

    // "The task service shall be able to update task fields per task ID. The following fields are updatable:" //
    
    // Update task name by taskID //
    public void updateTaskName(String taskID, String newName) {
        Task task = taskMap.get(taskID);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        task.setName(newName);
    }

// Updates the task description per taskID //
    public void updateTaskDescription(String taskID, String newDescription) {
        Task task = taskMap.get(taskID);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        task.setDescription(newDescription);
    }

// Getter for getting taskID //
    public Task getTask(String taskID) {
        return taskMap.get(taskID);
    }
}