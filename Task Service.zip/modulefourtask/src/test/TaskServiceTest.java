package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import modulefourtask.Task;
import modulefourtask.TaskService;

class TaskServiceTest {

	@Test
	void testAddTask() {
		TaskService taskService = new TaskService();
		Task task = new Task("1", "Task 1", "Description of Task 1");
		
        taskService.addTask(task); // Test case for adding a valid task //
        assertEquals(task, taskService.getTask("1"));
        
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask(new Task("1", "Task 2", "Description of Task 2")); // Test case for adding a task with existing ID
        });
        
	}
    void testDeleteTask() {
        TaskService taskService = new TaskService();
        Task task = new Task("1", "Task 1", "Description of task 1");
        	taskService.addTask(task);
        
    // Test case for deleting a task //
    taskService.deleteTask("1");
    	assertNull(taskService.getTask("1"));

    // Test case for deleting a task that doesn't exist //
    assertThrows(IllegalArgumentException.class, () -> {
        taskService.deleteTask("2");
    });
}

@Test
	void testUpdateTaskName() {    // Test case for updating a task name //
    	TaskService taskService = new TaskService();
    	Task task = new Task("1", "Task 1", "Description of task 1");
    		taskService.addTask(task);

    	taskService.updateTaskName("1", "Updated Task 1");
    	assertEquals("Updated Task 1", taskService.getTask("1").getName());

    // Test case for updating a task that doesn't exist //
    	assertThrows(IllegalArgumentException.class, () -> {
        taskService.updateTaskName("2", "New Task Name");
    });
}

@Test
	void testUpdateTaskDescription() {
    	TaskService taskService = new TaskService();
    	Task task = new Task("1", "Task 1", "Description of task 1");
    		taskService.addTask(task);
    		
    // Test updating the task description
    	taskService.updateTaskDescription("1", "Updated description");
    	assertEquals("Updated description", taskService.getTask("1").getDescription());

    // Test case for updating a task that doesn't exist //
    	assertThrows(IllegalArgumentException.class, () -> {
        taskService.updateTaskDescription("2", "New description");
    });
}

}