package test;

import static org.junit.jupiter.api.Assertions.*;
import modulefourtask.Task;

import org.junit.jupiter.api.Test;

class TaskTest {

    @Test
    void testTaskCreation() {
        Task task = new Task("12345", "Task Name", "This is a valid description");
             // Asserts that test cases are valid/equal to criteria //
        assertEquals("12345", task.getTaskID());  // Gets valid TaskID //
        assertEquals("Task Name", task.getName()); // Gets valid task Name //
        assertEquals("This is a valid description", task.getDescription()); // Gets valid Description //
    }

    @Test
    void testTaskIdValidation() {
        // Test case for for taskID being too long //
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Java 101", "This is a valid description");
        });
        
        // Test case for taskID being null //
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "12345", "This is a valid description");
        });
    }

    @Test
    void testTaskNameValidation() {
        // Test case for null (task) Name //
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "This is a valid description");
        });

        // Test case for Name being too long //
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "This is a very long name that exceeds twenty characters", "This is a valid description");
        });
    }

    @Test
    void testTaskDescriptionValidation() {
        // Test case for Description being null //
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Sample Task", null);
        });

        // Test case for Description being too long //
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Sample Task", "This description is far too long to be valid. It exceeds fifty characters.");
        });
    }
}
